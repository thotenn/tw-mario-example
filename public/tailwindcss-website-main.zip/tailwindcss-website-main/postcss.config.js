module.exports = {
  plugins: {
    //tailwindcss: {},
    '@tailwindcss/jit': {},
    autoprefixer: {},
  },
}
